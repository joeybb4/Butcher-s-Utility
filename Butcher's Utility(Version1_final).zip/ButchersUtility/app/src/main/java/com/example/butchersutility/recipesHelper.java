package com.example.butchersutility;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class recipesHelper extends RecyclerView.Adapter<recipesHelper.MyViewHolder> {

    private final Context context;
    Activity activity;
    private final ArrayList <String> recipe_id, recipe_name, recipe_weight;
    private final MyDatabaseHelper myDB;

    recipesHelper(Activity activity,
                  Context context,
                  ArrayList <String> recipe_id,
                  ArrayList <String> recipe_name,
                  ArrayList <String> recipe_weight){
        this.activity = activity;
        this.context = context;
        this.recipe_id = recipe_id;
        this.recipe_name = recipe_name;
        this.recipe_weight = recipe_weight;
        this.myDB = new MyDatabaseHelper(context);

    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View v = inflater.inflate(R.layout.recipe_row, parent, false);
        return new MyViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, final int position) {
        //this.position = position;

        holder.recipe_name.setText(String.valueOf(recipe_name.get(position)));
        holder.mainLayout.setOnClickListener(v -> {
            Intent i = new Intent(context, ingredientList.class);
            i.putExtra("id", String.valueOf(recipe_id.get(position)));
            i.putExtra("name", String.valueOf(recipe_name.get(position)));
            i.putExtra("weight", String.valueOf(recipe_weight.get(position)));
            activity.startActivityForResult(i,1);
        });
        holder.mainLayout.setOnLongClickListener(v -> {
            PopupMenu popupMenu = new PopupMenu(context, v);
            popupMenu.getMenuInflater().inflate(R.menu.recipe_delete_popup, popupMenu.getMenu());
            popupMenu.setOnMenuItemClickListener(item -> {
                int popId = item.getItemId();
                if(popId == R.id.delete_btn){
                    recipeDelete(position);
                    return true;
                }
                return false;
            });
            popupMenu.show();
            return true;
        });

    }
    private void recipeDelete(int position){
        String idsToDelete = String.valueOf(recipe_id.get(position));
        myDB.deleteAllIngredient(idsToDelete);
        myDB.deleteRecipe(idsToDelete);

        recipe_id.remove(position);
        recipe_name.remove(position);
        recipe_weight.remove(position);

        notifyItemRemoved(position);
        notifyItemRangeChanged(position,recipe_name.size());
        myDB.close();
    }

    @Override
    public int getItemCount()
    {
        return recipe_name.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {

        TextView recipe_name;
        LinearLayout mainLayout;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            recipe_name = itemView.findViewById(R.id.recipe_name);
            mainLayout = itemView.findViewById(R.id.mainLayout);
            Animation translate_anim = AnimationUtils.loadAnimation(context, R.anim.translate_anim);
            mainLayout.setAnimation(translate_anim);

        }
    }
}
