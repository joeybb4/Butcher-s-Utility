package com.example.butchersutility;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import android.widget.Toast;

public class MyDatabaseHelper extends SQLiteOpenHelper {
    public final Context context;
    public static final String DATABASE_NAME = "butchers.db";
    public static final int DATABASE_VERSION = 1;

    public static final String RECIPES = "recipes";
    public static final String COLUMN_RECIPE_NAME = "recipe_name";
    public static final String COLUMN_BASE_WEIGHT = "base_weight";
    public static final String COLUMN_ID = "id";

    public static final String INGREDIENTS = "ingredients";
    public static final String COLUMN_REFERENCE_ID = "reference_id";
    public static final String COLUMN_INGREDIENT_ID = "ingredients_id";
    public static final String COLUMN_INGREDIENT_NAME = "ingredients_name";
    public static final String COLUMN_INGREDIENT_PERCENTAGE = "ingredients_percentage";

    MyDatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        this.context = context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTableStatement0 = "CREATE TABLE " + RECIPES + " (" + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                " " + COLUMN_RECIPE_NAME + " TEXT, " + COLUMN_BASE_WEIGHT + " INTEGER)";

        String createTableStatement1 = "CREATE TABLE " + INGREDIENTS + " (" +
                COLUMN_INGREDIENT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_REFERENCE_ID + " INTEGER, " +
                COLUMN_INGREDIENT_NAME + " TEXT, " +
                COLUMN_INGREDIENT_PERCENTAGE + " INTEGER, " +
                "FOREIGN KEY(" + COLUMN_REFERENCE_ID + ") REFERENCES " + RECIPES + "(" + COLUMN_ID + "))";

        db.execSQL(createTableStatement0);
        db.execSQL(createTableStatement1);


    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + RECIPES);
        db.execSQL("DROP TABLE IF EXISTS " + INGREDIENTS);
        onCreate(db);
    }

    void addRecipe(String recipe, int base) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();

        cv.put(COLUMN_RECIPE_NAME, recipe);
        cv.put(COLUMN_BASE_WEIGHT, base);
        long insert = db.insert(RECIPES, null, cv);
        if (insert == -1) {
            Toast.makeText(context, "Failed!", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(context, "Recipe added!", Toast.LENGTH_SHORT).show();
        }
        db.close();
    }

    Cursor readData() {
        String query = "SELECT * From " + RECIPES;
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = null;
        if (db != null) {
            cursor = db.rawQuery(query, null);
        }
        return cursor;

    }

    public Cursor readIngredients(int row_id) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = null;

        if (db != null) {
            String query = "SELECT * FROM " + INGREDIENTS + " WHERE " + COLUMN_REFERENCE_ID + " = ?";
            cursor = db.rawQuery(query, new String[]{String.valueOf(row_id)});
            Log.d("row_id", "readIngredients: " + row_id);
        }

        return cursor;
    }

    /*public Cursor getPercent(int row_id) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = null;

        if (db != null) {
            String query = "SELECT " + COLUMN_INGREDIENT_PERCENTAGE +
                    " FROM " + INGREDIENTS +
                    " WHERE " + COLUMN_REFERENCE_ID + " = ?";
            cursor = db.rawQuery(query, new String[]{String.valueOf(row_id)});
        }
        return cursor;
    }*/


    void updateRecipe(String row_id, String name, String weight) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COLUMN_RECIPE_NAME, name);
        cv.put(COLUMN_BASE_WEIGHT, weight);

        long insert = db.update(RECIPES, cv, "id=?", new String[]{row_id});
        if (insert == -1) {
            Toast.makeText(context, "Failed!", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(context, "Recipe Updated!", Toast.LENGTH_SHORT).show();
        }
        db.close();
    }

    void updateIngredient(String row_id, String name, String percent) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COLUMN_INGREDIENT_NAME, name);
        cv.put(COLUMN_INGREDIENT_PERCENTAGE, percent);

        long insert = db.update(INGREDIENTS, cv, COLUMN_INGREDIENT_ID + "=?", new String[]{row_id});
        if (insert == -1) {
            Toast.makeText(context, "Failed!", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(context, "Recipe Updated!", Toast.LENGTH_SHORT).show();
        }
        db.close();
    }


    boolean addIngredients(int id, String name, float percentage) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();

        cv.put(COLUMN_REFERENCE_ID, id);
        cv.put(COLUMN_INGREDIENT_NAME, name);
        cv.put(COLUMN_INGREDIENT_PERCENTAGE, percentage);

        long result = db.insert(INGREDIENTS, null, cv);

        return result != -1;
    }
    public String getRecipeWeight(String recipeId) {
        SQLiteDatabase db = this.getReadableDatabase();
        String weight = null;

        if (db != null) {
            String query = "SELECT " + COLUMN_BASE_WEIGHT + " FROM " + RECIPES + " WHERE " + COLUMN_ID + " = ?";
            Cursor cursor = db.rawQuery(query, new String[]{recipeId});
            if (cursor.moveToFirst()) {
                weight = cursor.getString(cursor.getColumnIndex(COLUMN_BASE_WEIGHT));
            }
            cursor.close();
        }

        return weight;
    }
    void deleteIngredient(String id) {
        SQLiteDatabase db = this.getWritableDatabase();
        // Ensure id is a string that matches the primary key format in your database
        db.delete(INGREDIENTS,  COLUMN_INGREDIENT_ID + " = ?", new String[]{id});
        db.close();
    }

    void deleteAllIngredient(String id) {
        SQLiteDatabase db = this.getWritableDatabase();
        // Ensure id is a string that matches the primary key format in your database
        db.delete(INGREDIENTS,  COLUMN_REFERENCE_ID + " = ?", new String[]{id});
        db.close();
    }
    void deleteRecipe(String id) {
        SQLiteDatabase db = this.getWritableDatabase();
        // Ensure id is a string that matches the primary key format in your database
        db.delete(RECIPES,  COLUMN_ID + " = ?", new String[]{id});
        db.close();
    }
}