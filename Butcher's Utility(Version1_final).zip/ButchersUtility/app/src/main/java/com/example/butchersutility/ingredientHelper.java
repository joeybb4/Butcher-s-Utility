package com.example.butchersutility;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.TextView;

import androidx.activity.result.ActivityResultLauncher;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class ingredientHelper extends RecyclerView.Adapter<ingredientHelper.MyViewHolder> {

    private final Context context;
    private final ArrayList<String> ingredient_id, reference_id, ingredient_name, ingredient_percentage, ingredient_total;
    private final MyDatabaseHelper myDB;
    private final ActivityResultLauncher<Intent> updateIngredientActivityResultLauncher;




    public ingredientHelper(Context context, ArrayList<String> ingredient_id, ArrayList<String> reference_id,
                            ArrayList<String> ingredient_name, ArrayList<String> ingredient_percentage,
                            ArrayList<String> ingredient_totals, ActivityResultLauncher<Intent> launcher) {
        this.context = context;
        this.ingredient_id = ingredient_id;
        this.reference_id = reference_id;
        this.ingredient_name = ingredient_name;
        this.ingredient_percentage = ingredient_percentage;
        this.ingredient_total = ingredient_totals;
        this.myDB = new MyDatabaseHelper(context);
        this.updateIngredientActivityResultLauncher = launcher;
    }


    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View v = inflater.inflate(R.layout.ingredient_row, parent, false);
        return new MyViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, final int position) {
        //myDB = new MyDatabaseHelper(ingredientHelper.this);
        holder.name.setText(ingredient_name.get(position));
        holder.percent.setText(ingredient_percentage.get(position));
        holder.total.setText(ingredient_total.get(position));

        holder.linearLayout.setOnLongClickListener(v -> {
            //Intent intent = new Intent(context, updateRemoveIngredient.class);
            PopupMenu popupMenu = new PopupMenu(context, v);
            popupMenu.getMenuInflater().inflate(R.menu.ingredient_popup,popupMenu.getMenu());

            popupMenu.setOnMenuItemClickListener(item -> {
                int id = item.getItemId();
                if(id == R.id.edit){
                    //Toast.makeText(context, "edit clicked", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(context, updateRemoveIngredient.class);
                    intent.putExtra("ingredient_id", String.valueOf(ingredient_id.get(position)));
                    //intent.putExtra("reference_id", reference_id.get(position));
                    intent.putExtra("name", String.valueOf(ingredient_name.get(position)));
                    intent.putExtra("percent", String.valueOf(ingredient_percentage.get(position)));
                    updateIngredientActivityResultLauncher.launch(intent);
                    return true;
                } else if (id == R.id.delete) {
                    ingredient_delete(position);
                    return true;
                }
                return false;
            });

            popupMenu.show();
            return true;
        });
    }
    private void ingredient_delete(int position){
        if (position >= 0 && position < ingredient_id.size()) {
            String idtodelete = String.valueOf(ingredient_id.get(position));
            //myDB = new MyDatabaseHelper(context);
            myDB.deleteIngredient(idtodelete);

            // Remove the item from the lists
            ingredient_id.remove(position);
            reference_id.remove(position);
            ingredient_name.remove(position);
            ingredient_percentage.remove(position);
            ingredient_total.remove(position);

            notifyItemRemoved(position);
            notifyItemRangeChanged(position, ingredient_id.size());
            myDB.close();
        } else {
            Log.e("ingredientHelper", "Position out of bounds: " + position);
        }
    }


    @Override
    public int getItemCount() {
        return ingredient_name.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView name, percent, total;
        LinearLayout linearLayout;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            name = itemView.findViewById(R.id.ingredient_name);
            percent = itemView.findViewById(R.id.percent);
            total = itemView.findViewById(R.id.total_weight);
            linearLayout = itemView.findViewById(R.id.ingredient_layout);
            Animation translate_anim = AnimationUtils.loadAnimation(context, R.anim.translate_anim);
            linearLayout.setAnimation(translate_anim);
        }
    }
}
