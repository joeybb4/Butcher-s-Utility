package com.example.butchersutility;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class meatFatCalc extends AppCompatActivity {

    EditText meatVar, percentVar;
    TextView output;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_meat_fat_calc);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;

        });
        meatVar = findViewById(R.id.meatWeight);
        percentVar = findViewById(R.id.percentFat);

        output = findViewById(R.id.answer);
    }
    public void calcFatButton(View v) {
        String m, p;
        m = meatVar.getText().toString();
        p = percentVar.getText().toString();

        double meatWeight;
        double tempFat;

        if (!p.matches("^0*(?:[1-9][0-9]?|99)$")) {
            output.setText("Fat needs to be a whole number between 0-100.");
        } else if (!m.matches("^\\d+(\\.\\d+)?")) {
            output.setText("Weight needs to be a positive number.");
        } else {
            tempFat = Integer.parseInt(p);
            meatWeight = Double.parseDouble(m);
            double factor = (double)100 - tempFat;
            double fat = factor / (double) 100;
            double sub = meatWeight / fat;
            double result = sub - meatWeight;

            output.setText("Weight of Fat needed is " + String.format("%.2f", result));
        }

    }
}























