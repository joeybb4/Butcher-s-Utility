package com.example.butchersutility;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class Percent_Recipes extends AppCompatActivity {
    RecyclerView recyclerView;
    FloatingActionButton add_btn;

    MyDatabaseHelper myDB;
    ArrayList<String> recipe_id, recipe_name, recipe_weight;
    recipesHelper recipesHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_percent_recipes);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        recyclerView = findViewById(R.id.recyclerView);
        add_btn = findViewById(R.id.add_btn);
        add_btn.setOnClickListener(v -> {
            Intent i = new Intent(Percent_Recipes.this, addActivity.class);
            startActivity(i);
        });

        myDB = new MyDatabaseHelper(Percent_Recipes.this);
        recipe_id = new ArrayList<>();
        recipe_name = new ArrayList<>();
        recipe_weight = new ArrayList<>();

        storeData();

        recipesHelper = new recipesHelper(Percent_Recipes.this, this, recipe_id, recipe_name, recipe_weight);
        recyclerView.setAdapter(recipesHelper);
        recyclerView.setLayoutManager(new LinearLayoutManager(Percent_Recipes.this));
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == 1){
            recreate();
        }

    }

    void storeData() {
        Cursor cursor = myDB.readData();
        if(cursor.getCount() == 0) {
            Toast.makeText(this, "no Recipes available", Toast.LENGTH_SHORT).show();
        }else{
            while (cursor.moveToNext()) {
                recipe_id.add(cursor.getString(0));
                recipe_name.add(cursor.getString(1));
                recipe_weight.add(cursor.getString(2));
            }
        }
        myDB.close();
    }
}