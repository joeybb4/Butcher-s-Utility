package com.example.butchersutility;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class addIngredient extends AppCompatActivity {

    EditText et_ingredient_name, et_percentage;
    Button add_ingredient_btn2;
    String id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_add_ingredient);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Retrieve recipe id from intent extras
        Intent intent = getIntent();
        id = intent.getStringExtra("id");

        // Initialize views
        et_ingredient_name = findViewById(R.id.et_ingredient_name);
        et_percentage = findViewById(R.id.et_percentage);
        add_ingredient_btn2 = findViewById(R.id.add_ingredient_btn2);

        add_ingredient_btn2.setOnClickListener(v -> {
            // Get ingredient details from EditText fields
            String ingredientName = et_ingredient_name.getText().toString().trim();
            String percentage = et_percentage.getText().toString().trim();

            // Validate inputs (optional)
            if (ingredientName.isEmpty() || percentage.isEmpty()) {
                Toast.makeText(addIngredient.this, "Please fill all fields", Toast.LENGTH_SHORT).show();
                return;
            }

            try {
                // Insert ingredient into database
                MyDatabaseHelper myDB = new MyDatabaseHelper(addIngredient.this);
                boolean success = myDB.addIngredients(Integer.parseInt(id),
                        ingredientName,
                        Float.parseFloat(percentage));
                myDB.close(); // Close database connection

                if (success) {
                    // Send result back to the calling activity
                    Intent resultIntent = new Intent();
                    setResult(Activity.RESULT_OK, resultIntent);  // Indicate success
                } else {
                    setResult(Activity.RESULT_CANCELED);  // Indicate failure
                }
                finish();  // End the activity

            } catch (NumberFormatException e) {
                // Handle NumberFormatException (e.g., if id or percentage cannot be parsed to integer)
                Toast.makeText(addIngredient.this, "Invalid input", Toast.LENGTH_SHORT).show();
            }
        });
    }
}