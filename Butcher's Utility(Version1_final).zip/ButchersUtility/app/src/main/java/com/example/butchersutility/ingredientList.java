package com.example.butchersutility;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class ingredientList extends AppCompatActivity {

    EditText et_recipe_name2;
    EditText et_base_weight2;
    Button add_ingredient_btn, update_btn;

    MyDatabaseHelper myDB;
    RecyclerView recyclerView2;
    ArrayList<String> ingredient_id, reference_id, ingredient_name, ingredient_percentage, totals;
    ingredientHelper ingredientHelper;

    String id, name, weight;
    int row_id;

    private final ActivityResultLauncher<Intent> updateIngredientActivityResultLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == Activity.RESULT_OK) {
                    // Refresh the ingredient list
                    displayIngredients(row_id);
                }
            }
    );


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_ingredient_list);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        Intent intent = getIntent();
        id = intent.getStringExtra("id");
        row_id = Integer.parseInt(id);

        // Initialize database helper
        myDB = new MyDatabaseHelper(ingredientList.this);

        // Initialize views
        recyclerView2 = findViewById(R.id.recyclerView2);
        et_recipe_name2 = findViewById(R.id.et_recipe_name2);
        et_base_weight2 = findViewById(R.id.et_base_weight2);
        update_btn = findViewById(R.id.update_btn);
        add_ingredient_btn = findViewById(R.id.add_ingredient_btn);

        // Initialize lists
        ingredient_id = new ArrayList<>();
        reference_id = new ArrayList<>();

        ingredient_name = new ArrayList<>();
        ingredient_percentage = new ArrayList<>();
        totals = new ArrayList<>();

        // Get and set intent data
        getAndSetIntentData();


        // Initialize RecyclerView adapter
        ingredientHelper = new ingredientHelper(ingredientList.this,
                ingredient_id,
                reference_id,
                ingredient_name,
                ingredient_percentage,
                totals,
                updateIngredientActivityResultLauncher
        );
        recyclerView2.setAdapter(ingredientHelper);
        recyclerView2.setLayoutManager(new LinearLayoutManager(ingredientList.this));

        displayIngredients(row_id);
        // Handle button clicks
        add_ingredient_btn.setOnClickListener(v -> {
            Intent addingr = new Intent(ingredientList.this, addIngredient.class);
            addingr.putExtra("id", id);
            addIngredientActivityResultLauncher.launch(addingr);
        });

        update_btn.setOnClickListener(v -> {
            // Update recipe details in database
            String name = et_recipe_name2.getText().toString().trim();
            String weight = et_base_weight2.getText().toString().trim();
            myDB.updateRecipe(id, name, weight);

            displayIngredients(row_id);

            // Update displayed data
            et_recipe_name2.setText(name); // Update the EditText (optional)
            et_base_weight2.setText(weight); // Update the EditText (optional)
            myDB.close();
        });
        //displayIngredients(row_id);
    }


    // get recipe table from
    void getAndSetIntentData () {
        if(getIntent().hasExtra("id") && getIntent().hasExtra("name") &&
                getIntent().hasExtra("weight")) {

            id = getIntent().getStringExtra("id");
            name = getIntent().getStringExtra("name");
            weight = getIntent().getStringExtra("weight");



            et_recipe_name2.setText(name);
            et_base_weight2.setText(weight);

        }else{
            Toast.makeText(this, "No data", Toast.LENGTH_SHORT).show();
        }

    }

    private final ActivityResultLauncher<Intent> addIngredientActivityResultLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == Activity.RESULT_OK) {
                    // Refresh the ingredient list
                    displayIngredients(row_id);
                }
            }
    );



    @SuppressLint("NotifyDataSetChanged")
    void displayIngredients(int row_id) {
        ingredient_id.clear();
        reference_id.clear();
        ingredient_name.clear();
        ingredient_percentage.clear();
        totals.clear();

        weight = myDB.getRecipeWeight(String.valueOf(row_id));

        Cursor cursor = myDB.readIngredients(row_id);
        if (cursor == null || cursor.getCount() == 0) {
            Toast.makeText(this, "No ingredients found!", Toast.LENGTH_SHORT).show();
        } else {
            while (cursor.moveToNext()) {
                ingredient_id.add(cursor.getString(0));
                reference_id.add(cursor.getString(1));
                ingredient_name.add(cursor.getString(2));
                ingredient_percentage.add(cursor.getString(3));
                String total = totalCalc(weight, cursor.getString(3));
                totals.add(total);
            }
        }
        ingredientHelper.notifyDataSetChanged();
        myDB.close();
    }

    String totalCalc(String weight, String percentage) {
        if (weight != null && percentage != null) {
            float int_weight = Float.parseFloat(weight);
            float int_percentage = Float.parseFloat(percentage);
            float dec = int_percentage / 100;
            float fin = int_weight * dec;
            String format = String.format("%.2f", fin);
            return format;
        } else {
            return "0"; // Handle null values gracefully
        }
    }

}