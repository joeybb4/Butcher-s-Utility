package com.example.butchersutility;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;


public class updateRemoveIngredient extends AppCompatActivity {

    EditText ingredient_input, percent_input;
    Button update_btn;

    String id, name, percent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_update_remove_ingredient);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        ingredient_input = findViewById(R.id.et_ingredient_name2);
        percent_input = findViewById(R.id.et_percentage2);
        update_btn = findViewById(R.id.update_ingredient_btn);
        getIngredientData();
        update_btn.setOnClickListener(v -> {
            String name2 = ingredient_input.getText().toString().trim();
            String percent2 = percent_input.getText().toString().trim();
            if (!name2.isEmpty() && !percent2.isEmpty()) {
                MyDatabaseHelper myDB;
                myDB = new MyDatabaseHelper(updateRemoveIngredient.this);
                myDB.updateIngredient(id, name2, percent2);

                Intent resultIntent = new Intent();
                resultIntent.putExtra("ingredient_id", id);
                resultIntent.putExtra("name", name2);
                resultIntent.putExtra("percent", percent2);
                setResult(Activity.RESULT_OK, resultIntent);

                finish();
            } else {
                Toast.makeText(updateRemoveIngredient.this, "Fill all fields!", Toast.LENGTH_SHORT).show();
            }
        });

    }
    void getIngredientData() {
        if(getIntent().hasExtra("ingredient_id") && getIntent().hasExtra("name") &&
                getIntent().hasExtra("percent")){
            id = getIntent().getStringExtra("ingredient_id");
            name = getIntent().getStringExtra("name");
            percent = getIntent().getStringExtra("percent");

            ingredient_input.setText(name);
            percent_input.setText(percent);
        }else{
            Toast.makeText(this, "No data!", Toast.LENGTH_SHORT).show();
        }
    }

}