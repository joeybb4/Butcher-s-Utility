package com.example.butchersutility;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class addActivity extends AppCompatActivity {
    EditText et_recipe_name, et_base_weight;
    Button add_recipe_btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.add_activity);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        et_recipe_name = findViewById(R.id.et_recipe_name);
        et_base_weight = findViewById(R.id.et_base_weight);
        add_recipe_btn = findViewById(R.id.add_recipe_btn);
        add_recipe_btn.setOnClickListener(v -> {
            MyDatabaseHelper myDB = new MyDatabaseHelper(addActivity.this);
            myDB.addRecipe(et_recipe_name.getText().toString().trim(),
                    Integer.parseInt(et_base_weight.getText().toString().trim()));
            Intent i = new Intent(addActivity.this, Percent_Recipes.class);
            startActivity(i);
            myDB.close();
            finish();
        });
    }
}